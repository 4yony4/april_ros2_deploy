#pragma once

#include <stdexcept>

#include "hicem_core/base_component/enum_error_level.hpp"
#include "hicem_core/mediator/mediator.hpp"

namespace hicem::core
{
class BaseComponent
{
public:
  struct ErrorLog
  {
    std::string module;
    std::string method;
    EnumErrorLevel errorLevel;
    std::string errorMessage;
    double timestamp;
  };

  BaseComponent(Mediator* mediatorPtr);
  ~BaseComponent();
  BaseComponent(const BaseComponent&) = delete;
  BaseComponent& operator=(const BaseComponent&) = delete;
  BaseComponent(BaseComponent&&) = delete;
  BaseComponent& operator=(BaseComponent&&) = delete;

  void setMediator(Mediator* mediatorPtr);
  static void parseNestedException(const std::exception& e, std::string& what);

protected:
  virtual void logError(const ErrorLog& error);

  Mediator* mMediatorPtr;
};
}  // namespace hicem::core
