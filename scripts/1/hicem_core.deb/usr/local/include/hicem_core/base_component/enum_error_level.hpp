#pragma once

#include <stdexcept>
#include <string>
#include <iostream>
#include <algorithm>

namespace hicem::core
{
enum EnumErrorLevel
{
  NO,
  INFO,
  WARN,
  ERROR,
  FATAL
};

static EnumErrorLevel enumErrorLevelFromString(const std::string& enumName)
{
  // convert string to upper case
  std::string enumNameUpperCase = enumName;
  std::for_each(enumNameUpperCase.begin(), enumNameUpperCase.end(), [](char& c) { c = ::toupper(c); });

  EnumErrorLevel enumValue;
  if (enumNameUpperCase == "NO")
  {
    enumValue = EnumErrorLevel::NO;
  }
  else if (enumNameUpperCase == "INFO")
  {
    enumValue = EnumErrorLevel::INFO;
  }
  else if (enumNameUpperCase == "WARN")
  {
    enumValue = EnumErrorLevel::WARN;
  }
  else if (enumNameUpperCase == "ERROR")
  {
    enumValue = EnumErrorLevel::ERROR;
  }
  else if (enumNameUpperCase == "FATAL")
  {
    enumValue = EnumErrorLevel::FATAL;
  }
  else
  {
    std::string msg = "Invalid EnumErrorLevel name '" + enumNameUpperCase + "'!";
    throw std::invalid_argument(msg);
  }

  return enumValue;
};

static std::string enumErrorLevelToString(const EnumErrorLevel& enumValue)
{
  std::string enumName;
  switch (enumValue)
  {
    case EnumErrorLevel::NO:
      enumName = "NO";
      break;
    case EnumErrorLevel::INFO:
      enumName = "INFO";
      break;
    case EnumErrorLevel::WARN:
      enumName = "WARN";
      break;
    case EnumErrorLevel::ERROR:
      enumName = "ERROR";
      break;
    case EnumErrorLevel::FATAL:
      enumName = "FATAL";
      break;
    default:
      std::string msg = "Unrecognized EnumErrorLevel value '" + std::to_string(enumValue) + "'!";
      throw std::invalid_argument(msg);
  }

  return enumName;
};
}  // namespace hicem::core
