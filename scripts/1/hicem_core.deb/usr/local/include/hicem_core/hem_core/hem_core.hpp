#pragma once

#include <atomic>
#include <tuple>
#include <uv.h>
#include <string>

#include "hicem_core/base_component/base_component.hpp"
#include "hicem_core/hdm/hdm.hpp"
#include "hicem_core/nlohmann/json.hpp"

// for convenience
using json = nlohmann::json;

namespace hicem::core
{
class HemCore : public BaseComponent
{
public:
  struct structQueueWork
  {
    uv_work_t req;
    HemCore* obj;
    json data;
  };

  struct structTimerHandler
  {
    uv_timer_t handle;
    HemCore* obj;
    json data;
  };

  HemCore(Mediator* mediatorPtr);
  ~HemCore();
  HemCore(const HemCore&) = delete;
  HemCore& operator=(const HemCore&) = delete;
  HemCore(HemCore&&) = delete;
  HemCore& operator=(HemCore&&) = delete;

  virtual void init();
  void shutdown();
  void start();
  void processMonitoringFunction(json data);
  bool isRunning();

protected:
  void initEventLoop();

private:
  virtual void monitoringFunction(json& data) = 0;  // be careful, executed on a separate thread

  static void callbackQueueWork(uv_work_t* req);
  static void callbackQueueWorkDone(uv_work_t* req, int status);
  static void threadWorker(void* arg);
  static void timerCallback(uv_timer_t* handle);
  void stopEventLoop();
  bool giveHighPriorityCommand();

  bool mIsInit;
  std::atomic<bool> mIsRunning;
  std::unique_ptr<structTimerHandler> mTimer;

  uv_loop_t mEventLoop;
  uv_thread_t mEventThread;
  uv_timer_t mEventTimer;
};
}  // namespace hicem::core
