#pragma once

namespace hicem::core
{
enum EnumControllingFunctionActions
{
  START,
  STOP
};
}
