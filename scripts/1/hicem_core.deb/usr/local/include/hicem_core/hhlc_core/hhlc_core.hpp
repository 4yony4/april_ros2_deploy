#pragma once

#include <map>
#include <mutex>
#include <string>

#include <uv.h>

#include "hicem_core/base_component/base_component.hpp"
#include "hicem_core/base_component/enum_error_level.hpp"
#include "hicem_core/hhlc_core/enum_controlling_function_actions.hpp"
#include "hicem_core/nlohmann/json.hpp"
#include "hicem_core/bt_engine/bt_engine.hpp"

using json = nlohmann::json;

namespace hicem::core
{
class HhlcCore : public BaseComponent
{
public:
  struct executeControllingFunction
  {
    uv_work_t req;
    HhlcCore* obj;
    json data;
  };

  struct handleErrorStruct
  {
    uv_work_t req;
    HhlcCore* obj;
    ErrorLog error;
  };

  struct structTimerHandler
  {
    uv_timer_t handle;
    HhlcCore* obj;
    json data;
  };

  HhlcCore(Mediator* mediatorPtr);
  ~HhlcCore();
  HhlcCore(const HhlcCore&) = delete;
  HhlcCore& operator=(const HhlcCore&) = delete;
  HhlcCore(HhlcCore&&) = delete;
  HhlcCore& operator=(HhlcCore&&) = delete;

  virtual bool stopCurrentGoal() = 0;

  void initEventLoop();
  void shutdown();
  void start();
  void addBtModelArguments(const json& data);
  void addErrorLog(const ErrorLog& error);
  void updateControllingFunction(const json& data);
  void updateErrorHandler(const ErrorLog& error);
  bool isRunning();
  json getBtModelArguments();
  ErrorLog getErrorLog();

protected:
  virtual void controllingFunction(const json& data) = 0;  // be careful, executed on a separate thread
  virtual void handleError(const ErrorLog& error) = 0;     // be careful, executed on a separate thread

  BtEngine mBtEngine;

private:
  static void callbackExecuteControllingFunction(uv_work_t* req);
  static void callbackExecuteControllingFunctionDone(uv_work_t* req, int status);
  static void callbackHandleError(uv_work_t* req);
  static void callbackHandleErrorDone(uv_work_t* req, int status);
  static void threadWorker(void* arg);
  static void timerCallback(uv_timer_t* handle);

  void stopEventLoop();

  bool mIsInit;
  std::atomic<bool> mIsRunning;
  std::unique_ptr<structTimerHandler> mTimer;

  std::mutex mBtModelArgumentsMutex, mErrorLogContainerMutex;
  std::map<EnumErrorLevel, std::queue<ErrorLog>> mErrorLogContainer;

  uv_loop_t mEventLoop;
  uv_thread_t mEventThread;
  uv_timer_t mEventTimer;

  json mBtModelArguments;
};
}  // namespace hicem::core
