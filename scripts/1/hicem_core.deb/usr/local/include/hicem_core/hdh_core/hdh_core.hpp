#pragma once

#include "hicem_core/base_component/base_component.hpp"

namespace hicem::core
{
  class HdhCore : public BaseComponent
  {
  public:
    HdhCore(Mediator* mediatorPtr);
    ~HdhCore();
    HdhCore(const HdhCore&) = delete;
    HdhCore& operator=(const HdhCore&) = delete;
    HdhCore(HdhCore&&) = delete;
    HdhCore& operator=(HdhCore&&) = delete;
  };
}