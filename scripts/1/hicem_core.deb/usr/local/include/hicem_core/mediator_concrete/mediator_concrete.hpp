#pragma once

#include <any>
#include "hicem_core/mediator/mediator.hpp"
#include "hicem_core/mediator_concrete/enum_modules.hpp"
#include "hicem_core/mediator_concrete/enum_methods.hpp"
#include "hicem_core/nlohmann/json.hpp"
#include "hicem_core/hdm/hdm.hpp"
#include "hicem_core/hem_core/hem_core.hpp"
#include "hicem_core/hhlc_core/hhlc_core.hpp"
#include "hicem_core/hdh_core/hdh_core.hpp"

// for convenience
using json = nlohmann::json;

namespace hicem::core
{
class MediatorConcrete : public Mediator
{
public:
  MediatorConcrete(Hdm* hdmPtr, HemCore* hemCorePtr, HhlcCore* hhlcCorePtr, HdhCore* hdhCorePtr);
  ~MediatorConcrete();
  MediatorConcrete(const MediatorConcrete&) = delete;
  MediatorConcrete& operator=(const MediatorConcrete&) = delete;
  MediatorConcrete(MediatorConcrete&&) = delete;
  MediatorConcrete& operator=(MediatorConcrete&&) = delete;

  std::any call(std::any module, std::any method, std::any args) override;

private:
  std::any callHdh(std::any method, std::any args);
  std::any callHdm(std::any method, std::any args);
  std::any callHem(std::any method, std::any args);
  std::any callHhlc(std::any method, std::any args);

  Hdm* mHdmPtr;
  HemCore* mHemCorePtr;
  HhlcCore* mHhlcCorePtr;
  HdhCore* mHdhCorePtr;
};
}  // namespace hicem::core
