#pragma once

namespace hicem::core
{
  enum EnumModules
  {
    HDH,
    HDM,
    HEM,
    HHLC
  };
}
