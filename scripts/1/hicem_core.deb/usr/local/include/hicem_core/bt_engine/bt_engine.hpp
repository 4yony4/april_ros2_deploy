#pragma once

#include <behaviortree_cpp/bt_factory.h>
#include <behaviortree_cpp/loggers/bt_zmq_publisher.h>
#include <chrono>
#include <map>
#include <mutex>
#include <thread>

#include "hicem_core/base_component/base_component.hpp"
#include "hicem_core/base_component/enum_error_level.hpp"

// It is mandatory to define a template specialization of convertFromString that converts a string to
// hicem::core::BaseComponent::ErrorLog.
namespace BT
{
template <>
inline hicem::core::BaseComponent::ErrorLog convertFromString(BT::StringView str)
{
  // The next line should be removed...
  printf("Converting string: \"%s\"\n", str.data());

  // We expect real numbers separated by semicolons
  auto parts = BT::splitString(str, ';');
  if (parts.size() != 5)
  {
    throw BT::RuntimeError("invalid input)");
  }
  else
  {
    hicem::core::BaseComponent::ErrorLog output;
    output.module = convertFromString<std::string>(parts[0]);
    output.method = convertFromString<std::string>(parts[1]);
    output.errorLevel = static_cast<hicem::core::EnumErrorLevel>(BT::convertFromString<int>(parts[2]));
    output.errorMessage = convertFromString<std::string>(parts[3]);
    output.timestamp = convertFromString<double>(parts[4]);
    return output;
  }
}
}  // end namespace BT

namespace hicem::core
{
class BtEngine
{
public:
  BtEngine();
  ~BtEngine();
  BtEngine(const BtEngine&) = delete;
  BtEngine& operator=(const BtEngine&) = delete;
  BtEngine(BtEngine&&) = delete;
  BtEngine& operator=(BtEngine&&) = delete;

  void addBtModel(const std::string& btModelName, const std::string& filePath);
  void addBtModel(const std::string& btModelName, const char* xmlBtModel);
  void executeBt(const std::string& btModelName);
  void executeErrorHandlingBt(const std::string& btModelName);
  void setBtMonitorFlag(bool state);

  bool interruptCurrentBt();
  std::string getCurrentBtModel();
  std::string getCurrentBtStatus();
  std::string getLastBtStatus();

  BT::BehaviorTreeFactory mBtFactory;

private:
  void setCurrentBtModel(const std::string& btModelName);
  void setLastBtStatus(const std::string& lastBtStatus);
  std::map<std::string, BT::Tree>::iterator getBtModelsEnd();
  std::map<std::string, BT::Tree>::iterator getBtModel(std::string modelName);

  std::mutex mBtModelsMutex, mCurrentBtModelMutex, mLastBtStatusMutex;

  std::atomic<bool> mBtMonitorFlag;
  std::unique_ptr<BT::PublisherZMQ> mBtZmqPublisher, mErrorHandlingBtZmqPublisher;

  std::string mCurrentBtModel;
  std::map<std::string, BT::Tree> mBtModels;

  std::string mLastBtStatus;
};
}  // namespace hicem::core
