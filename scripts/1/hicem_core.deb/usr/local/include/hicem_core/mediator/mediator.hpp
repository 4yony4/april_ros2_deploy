#pragma once

#include <any>
#include <string>

namespace hicem::core
{
  class Mediator
  {
  public:
    virtual std::any call(std::any module, std::any method, std::any args) = 0;
  };
}
