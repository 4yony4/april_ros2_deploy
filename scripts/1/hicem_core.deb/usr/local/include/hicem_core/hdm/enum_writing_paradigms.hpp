#pragma once

namespace hicem::core
{
enum EnumWritingParadigms
{
  KEEP_THE_NEWEST_ONE,
  BUILD_UP_INFORMATION,
  KEEP_RECENT_HISTORY,
  KEEP_ALL
};
}
