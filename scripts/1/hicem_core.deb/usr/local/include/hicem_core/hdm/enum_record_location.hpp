#pragma once

namespace hicem::core
{
enum EnumRecordLocation
{
  FILE,
  DB
};
}
