#pragma once

#include <any>
#include <boost/date_time.hpp>
#include <deque>
#include <filesystem>
#include <fstream>  // dump json to the file
#include <iomanip>
#include <iostream>
#include <map>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

#include "hicem_core/base_component/base_component.hpp"
#include "hicem_core/hdm/enum_reading_paradigms.hpp"
#include "hicem_core/hdm/enum_record_location.hpp"
#include "hicem_core/hdm/enum_writing_paradigms.hpp"
#include "hicem_core/nlohmann/json.hpp"

// for convenience
using json = nlohmann::json;

namespace hicem::core
{
class Hdm : public BaseComponent
{
public:
  struct HdmArgs
  {
    bool updateVolatileOnStartup;
    EnumRecordLocation recordLocation;
    std::string recordPath;
  };

  struct WriteData
  {
    std::string source;
    EnumWritingParadigms writingParadigm;
    double writingParadigmDuration;
    std::string writingParadigmKey;
    json data;
  };

  struct ReadData
  {
    std::string source;
    EnumReadingParadigms readParadigm;
    EnumWritingParadigms storageParadigm;
    double timestamp;
    json data;
  };

  struct RecordData
  {
    bool volatileClear;
    json data;
  };

  struct BuildUpInformation
  {
    std::string writingParadigmKey;
    std::map<std::string, json> data;
  };

  struct KeepRecentHistory
  {
    double writingParadigmDuration;
    std::vector<std::pair<double, json>> data;
  };

  Hdm(Mediator* mediatorPtr, HdmArgs args);
  ~Hdm();
  Hdm(const Hdm&) = delete;
  Hdm& operator=(const Hdm&) = delete;
  Hdm(Hdm&&) = delete;
  Hdm& operator=(Hdm&&) = delete;

  void readData(ReadData& dataInfo);
  void recordData(RecordData& dataInfo);
  void writeData(const WriteData& data);

private:
  void updateVolatileFromDB();
  void updateVolatileFromFile();
  void updateVolatileFromPermanent();
  void buildUpInformation(const WriteData& data);
  void buildUpInformation(const std::string& collectionName, const json& data);
  void keepAll(const WriteData& data);
  void keepAll(const std::string& collectionName, const json& data);
  void keepNewestOne(const WriteData& data);
  void keepNewestOne(const std::string& collectionName, const json& data);
  void keepRecentHistory(const WriteData& data);
  void keepRecentHistory(const std::string& collectionName, const json& data);
  void removeDepercatedEntries(std::map<std::string, hicem::core::Hdm::KeepRecentHistory>::iterator& iterator,
                               const double& timestamp);
  void getDataBuildUpInformation(const std::string& source, json& data);
  void getDataKeepAll(const std::string& source, json& data);
  void getDataKeepRecent(const std::string& source, const double& timestamp, json& data);
  void getDataKeepTheNewestOne(const std::string& source, json& data);
  void getSortedFiles(std::vector<std::filesystem::path>& paths);
  void readFromVolatileDatabase(ReadData& dataInfo);
  void volatileToDB(RecordData& dataInfo);
  void volatileToFile(RecordData& dataInfo);

  std::string getFileName();
  std::string getFieldValue(const json& jsonData, const std::string& writingParadigmKey);
  json getJsonFromDeque(std::deque<json> dequeData);
  json getJsonFromMap(std::map<std::string, json> mapData);
  json getJsonFromVectorOfPairs(const std::vector<std::pair<double, json>>& vectorData);

  std::mutex mBuildUpInformationMutex, mKeepAllMutex, mKeepNewestOneMutex, mKeepRecentHistoryMutex;

  std::filesystem::path mRecordPath;
  EnumRecordLocation mRecordLocation;

  std::map<std::string, BuildUpInformation> mBuildUpInformationVolatileDatabase;
  std::map<std::string, std::deque<json>> mKeepAllVolatileDatabase;
  std::map<std::string, json> mKeepNewestOneVolatileDatabase;
  std::map<std::string, KeepRecentHistory> mKeepRecentHistoryVolatileDatabase;
};
}  // namespace hicem::core
