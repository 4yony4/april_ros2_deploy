#pragma once

namespace hicem::core
{
enum EnumReadingParadigms
{
  READ_FROM_PERMANENT_DATABASE,
  READ_FROM_VOLATILE_DATABASE
};
}
